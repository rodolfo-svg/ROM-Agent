# ROM Knowledge Base

Este diretório contém a Knowledge Base específica do projeto ROM.

## Estrutura:

- `modelos/` - Modelos de peças jurídicas
- `legislacao/` - Legislação frequente
- `jurisprudencia/` - Precedentes salvos
- `doutrina/` - Artigos e livros

Documentos aqui serão consultados automaticamente pela IA quando relevante.
