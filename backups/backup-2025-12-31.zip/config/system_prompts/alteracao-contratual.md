# Alteração Contratual (DNRC)

## Descrição
Alteração contratual em estrita conformidade com as normas do DNRC (IN DREI nº 81/2020) e legislação empresarial

**Categoria**: empresarial

**Tags**: alteração, contratual, dnrc, empresarial, sociedade, ltda

## Prompt



