# Incidente de Desconsideração da Personalidade Jurídica

## Descrição
Prompt para Incidente de Desconsideração da Personalidade Jurídica

**Categoria**: civel

## Prompt



