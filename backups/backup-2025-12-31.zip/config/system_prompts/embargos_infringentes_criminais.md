# Embargos Infringentes e de Nulidade

## Descrição
Prompt para Embargos Infringentes e de Nulidade

**Categoria**: criminal

## Prompt



