# Resposta à Acusação

## Descrição
Prompt para Resposta à Acusação

**Categoria**: criminal

## Prompt



