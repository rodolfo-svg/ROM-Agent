# Recurso Ordinário Trabalhista

## Descrição
Prompt para Recurso Ordinário Trabalhista

**Categoria**: trabalhista

## Prompt



