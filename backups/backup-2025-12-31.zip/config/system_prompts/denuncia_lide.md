# Denunciação da Lide

## Descrição
Prompt para Denunciação da Lide

**Categoria**: civel

## Prompt



