# Habeas Corpus

## Descrição
Habeas Corpus completo com 12 categorias de cabimento, modalidades preventiva e liberatória, e fundamentação constitucional

**Categoria**: criminal

**Tags**: habeas, corpus, criminal, liberdade, prisão

## Prompt



