# Alegações Finais Criminais

## Descrição
Prompt para Alegações Finais Criminais

**Categoria**: criminal

## Prompt



