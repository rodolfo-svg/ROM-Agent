# Petição Inicial Cível

## Descrição
Petição inicial completa conforme art. 319, CPC, com todos os requisitos legais e checklist de qualidade de 100 pontos

**Categoria**: civel

**Tags**: petição, inicial, cível, art319, primeiro grau

## Prompt



