# Método de Análise de Prazos Processuais

## Descrição
Metodologia técnica para análise e cálculo de prazos processuais com base na Lei 11.419/2006 e resoluções do CNJ

**Categoria**: geral

**Tags**: prazos, DJe, DJEN, preclusão, prescrição, decadência

## Prompt



