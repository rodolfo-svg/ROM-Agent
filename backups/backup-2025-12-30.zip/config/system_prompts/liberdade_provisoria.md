# Pedido de Liberdade Provisória

## Descrição
Prompt para Pedido de Liberdade Provisória

**Categoria**: criminal

## Prompt



