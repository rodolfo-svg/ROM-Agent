# Release Tags

- staging-validated-YYYYMMDD: staging validado (soak + checks)
- rc-<version>-YYYYMMDD: release candidate
- v<version>: produção
