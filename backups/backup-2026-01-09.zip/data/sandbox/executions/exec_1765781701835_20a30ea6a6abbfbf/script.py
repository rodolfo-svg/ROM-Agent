print("Hello from Python!")
for i in range(5):
    print(f"Número {i}")