# Recurso de Revista

## Descrição
Prompt para Recurso de Revista

**Categoria**: trabalhista

## Prompt



