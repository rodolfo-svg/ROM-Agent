# Habeas Corpus

## Descrição
Prompt para Habeas Corpus

**Categoria**: criminal

## Prompt



