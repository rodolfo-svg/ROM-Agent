# Pedido de Revogação de Prisão Preventiva

## Descrição
Prompt para Pedido de Revogação de Prisão Preventiva

**Categoria**: criminal

## Prompt



