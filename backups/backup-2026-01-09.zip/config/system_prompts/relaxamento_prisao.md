# Pedido de Relaxamento de Prisão

## Descrição
Prompt para Pedido de Relaxamento de Prisão

**Categoria**: criminal

## Prompt



