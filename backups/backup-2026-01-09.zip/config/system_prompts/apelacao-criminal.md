# Apelação Criminal

## Descrição
Prompt para Apelação Criminal

**Categoria**: criminal

## Prompt



