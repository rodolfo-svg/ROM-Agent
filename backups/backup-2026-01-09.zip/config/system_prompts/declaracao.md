# Declaração

## Descrição
Prompt para Declaração

**Categoria**: declaracoes

## Prompt



