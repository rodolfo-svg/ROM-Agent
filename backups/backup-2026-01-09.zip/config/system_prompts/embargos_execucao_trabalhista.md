# Embargos à Execução Trabalhista

## Descrição
Prompt para Embargos à Execução Trabalhista

**Categoria**: trabalhista

## Prompt



