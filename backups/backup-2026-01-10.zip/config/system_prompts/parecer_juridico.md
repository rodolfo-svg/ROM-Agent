# Parecer Jurídico

## Descrição
Prompt para Parecer Jurídico

**Categoria**: pareceres

## Prompt



