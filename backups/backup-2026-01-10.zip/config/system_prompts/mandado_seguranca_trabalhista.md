# Mandado de Segurança Trabalhista

## Descrição
Prompt para Mandado de Segurança Trabalhista

**Categoria**: trabalhista

## Prompt



