# Recurso Especial

## Descrição
Prompt para Recurso Especial

**Categoria**: civel

## Prompt



