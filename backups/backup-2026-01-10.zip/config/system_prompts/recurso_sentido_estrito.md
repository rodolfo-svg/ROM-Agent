# Recurso em Sentido Estrito

## Descrição
Prompt para Recurso em Sentido Estrito

**Categoria**: criminal

## Prompt



