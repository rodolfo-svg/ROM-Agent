# Embargos de Declaração

## Descrição
Prompt para Embargos de Declaração

**Categoria**: civel

## Prompt



