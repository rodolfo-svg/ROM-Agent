# Recurso Extraordinário

## Descrição
Prompt para Recurso Extraordinário

**Categoria**: civel

## Prompt



