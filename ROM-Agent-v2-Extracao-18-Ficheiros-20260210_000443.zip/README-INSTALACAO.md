# ROM Agent v2.0 - Guia de Instalação Rápida

## 📦 O QUE É ESTE PACOTE?

Sistema de extração de documentos jurídicos com análise profunda:
- **18 ficheiros estruturados** por documento
- **Análise jurídica com IA** (Claude)
- **Extração de entidades** (partes, valores, datas, leis)
- **Resumos executivos** em múltiplos níveis
- **Análise de risco** com recomendações

---

## 🚀 INSTALAÇÃO

### Windows

1. Abra PowerShell como Administrador
2. Navegue até a pasta extraída
3. Execute:
```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup-extracao-v2.ps1
```

### macOS

1. Abra Terminal
2. Navegue até a pasta extraída
3. Execute:
```bash
bash scripts/setup-extracao-v2.sh
```

### Linux

1. Abra Terminal
2. Navegue até a pasta extraída
3. Execute:
```bash
bash scripts/setup-extracao-v2-linux.sh
```

---

## ⚙️ CONFIGURAÇÃO

1. **Configure AWS Bedrock**:
   - Copie `.env.example` para `.env`
   - Adicione suas credenciais AWS

2. **Teste o sistema**:
```bash
node scripts/test-extraction-v2.js /caminho/documento.pdf
```

---

## 📚 DOCUMENTAÇÃO COMPLETA

Leia os arquivos:
- `EXTRACAO-V2-README.md` - Manual completo
- `IMPLEMENTACAO-COMPLETA.md` - Detalhes técnicos

---

## 💰 CUSTOS

- Documento pequeno (< 10 págs): $0.05-$0.15
- Documento médio (10-50 págs): $0.15-$0.50
- Documento grande (50-200 págs): $0.50-$2.00

---

## 📞 SUPORTE

Consulte a documentação incluída ou contate o desenvolvedor.

**ROM Agent v2.0** © 2026
